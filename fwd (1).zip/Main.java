public class Main
{
    Singleton S1=Singleton.getInstance();
    public static void main(String[] args)
    {
        System.out.print("Design Pattern with singleton class");
    }
    
}